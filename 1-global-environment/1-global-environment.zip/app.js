var a = 'Hello world';

function b() {

}